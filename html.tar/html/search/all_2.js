var searchData=
[
  ['cita',['Cita',['../class_cita.html',1,'Cita'],['../class_cita.html#a40ebe4fd414fa884f1aca3b78e77a38c',1,'Cita::Cita()'],['../class_cita.html#a845d1d6b672e1375d7dd032e52da7bba',1,'Cita::Cita(string referencia, const Text &amp;proceden, int ini, int fi)']]],
  ['cita_2ecc',['Cita.cc',['../_cita_8cc.html',1,'']]],
  ['cita_2ehh',['Cita.hh',['../_cita_8hh.html',1,'']]],
  ['cites',['cites',['../class_biblio.html#aa37dd0039a0209400b00b6d78b85e8a2',1,'Biblio']]],
  ['citesautor',['citesAutor',['../class_biblio.html#abc75aac89830feb2138a07adb31e0e19',1,'Biblio']]],
  ['comp',['comp',['../_text_8cc.html#addeff31bc9d6254a568671fb9c877130',1,'Text.cc']]],
  ['conscitesasso',['conscitesasso',['../class_text.html#a650a14db2590148227def780f5cad527',1,'Text']]],
  ['consulta_5fauto',['consulta_auto',['../class_text.html#a0ae2bd6e9cc483862997729b4bcde6b8',1,'Text']]],
  ['consulta_5fcontingut',['consulta_contingut',['../class_text.html#a63fbaa48e17fcb51fc5421b7d280459f',1,'Text']]],
  ['consulta_5finicials',['consulta_inicials',['../class_text.html#a3a59f5b9509e26c15bca04afd80bd10d',1,'Text']]],
  ['consulta_5ftitol',['consulta_titol',['../class_text.html#a9e85682f3abf95b41c672b9e2b143594',1,'Text']]],
  ['conteparaules',['conteParaules',['../class_text.html#ac34f65f5761983bb89bb55382718ec41',1,'Text']]],
  ['contingut',['contingut',['../class_biblio.html#a6a33718c5e1df48e8a1195aa50bd892c',1,'Biblio']]]
];
