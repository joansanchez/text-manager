var searchData=
[
  ['nombrefrases',['nombrefrases',['../class_biblio.html#a98d81eee30c8e0b213fd9949b1fa7da0',1,'Biblio']]],
  ['nombreparaules',['nombreparaules',['../class_biblio.html#abad728c98a83e2598ea1ac0240fac519',1,'Biblio']]],
  ['normalitzaciottlaut',['normalitzaciottlaut',['../program_8cc.html#a620acb5c17c79bde434b80da0ac14b44',1,'program.cc']]],
  ['normalitzar',['normalitzar',['../class_biblio.html#a9b5775030448b3a004538fb6fc76cef9',1,'Biblio::normalitzar()'],['../_text_8cc.html#a90255d8f366db45ebdb3df3de5b61d31',1,'normalitzar():&#160;Text.cc']]],
  ['normalitzarttl',['normalitzarttl',['../_text_8cc.html#af3783fdcd7101913da7c9c1c15d783ee',1,'Text.cc']]],
  ['num_5fpar',['num_par',['../class_text.html#aeab5085af96c10dc48db02f871fc8590',1,'Text']]],
  ['numero_5ffrases',['numero_frases',['../class_text.html#a74fe7559f26442cdfc8ee727d4fb8950',1,'Text']]]
];
