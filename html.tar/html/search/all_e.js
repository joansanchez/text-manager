var searchData=
[
  ['unio',['unio',['../class_text.html#a4076661ec995e4f99651bbc239e7547f',1,'Text']]]
];
