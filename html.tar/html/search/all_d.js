var searchData=
[
  ['tauladefrecuencies',['tauladefrecuencies',['../class_biblio.html#a12827f7e94d9d526a00c79de33252df7',1,'Biblio']]],
  ['taulafreqs',['taulafreqs',['../class_text.html#a8b9696d0af91d93f022ffb882a47f69d',1,'Text']]],
  ['taulafrequs',['taulafrequs',['../class_text.html#a6d1290219558c1068c4f2962088b0ada',1,'Text']]],
  ['text',['Text',['../class_text.html',1,'Text'],['../class_text.html#ab3e26143fccc52699bcc5149cae852bc',1,'Text::Text()'],['../class_text.html#a72ab4dd9226ef9d6a6462ff87aae93a8',1,'Text::Text(string titoltxt, string autortxt, vector&lt; vector&lt; string &gt; &gt; contingutaux)']]],
  ['text_2ecc',['Text.cc',['../_text_8cc.html',1,'']]],
  ['text_2ehh',['Text.hh',['../_text_8hh.html',1,'']]],
  ['textosautor',['TextosAutor',['../class_biblio.html#ad6dd3fccfc9c04d624ea3aa8c809702c',1,'Biblio']]],
  ['tit_5fproc',['tit_proc',['../class_cita.html#af85398852786e383983f467e9f817b5c',1,'Cita']]],
  ['totescites',['totescites',['../class_biblio.html#aba1e2f0dc4c7c1e59b91e38fdcdba66f',1,'Biblio']]],
  ['totsautors',['TotsAutors',['../class_biblio.html#a53e6abd9183cc70d801652e8155e7ff9',1,'Biblio']]],
  ['totstextos',['TotsTextos',['../class_biblio.html#a9ebec9d8ff26e7b0873275a12d1edf00',1,'Biblio']]],
  ['triartext',['TriarText',['../class_biblio.html#a04b8d434bdff5c161d15a05bb73d19e1',1,'Biblio']]],
  ['txt',['txt',['../class_cita.html#ac085013ca6375ddd06bb8c96147c9e72',1,'Cita']]]
];
