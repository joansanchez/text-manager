var searchData=
[
  ['imp_5fcontingut',['imp_contingut',['../class_cita.html#a39263e7fd5baea98fbd6c3176e1b74e0',1,'Cita']]],
  ['info',['info',['../class_biblio.html#ac1ec345fe162be35b3e19531ca705f4c',1,'Biblio']]],
  ['infocita',['infocita',['../class_biblio.html#adb4efc2b1843e316e035bcace87fa3d5',1,'Biblio']]],
  ['interseccio',['interseccio',['../class_text.html#acb7174cfbef305a1e4292822494be540',1,'Text']]]
];
