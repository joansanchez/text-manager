var searchData=
[
  ['operacio',['operacio',['../_text_8cc.html#a0366b8fe439dbc86a742ea86c644056a',1,'Text.cc']]]
];
