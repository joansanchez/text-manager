var searchData=
[
  ['_7ebiblio',['~Biblio',['../class_biblio.html#a4f96412b4cca4d84908c20f65cea8bbf',1,'Biblio']]],
  ['_7etext',['~Text',['../class_text.html#a2d49e5c280e205125b149f7777ae30c7',1,'Text']]]
];
