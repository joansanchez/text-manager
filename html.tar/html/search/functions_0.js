var searchData=
[
  ['afegircita',['afegircita',['../class_biblio.html#afeaf8f3011205e0d80389978f3381c4b',1,'Biblio']]],
  ['afegircitaref',['afegircitaref',['../class_text.html#a4d91742e5e1fe5a283ab0785a45e5c52',1,'Text']]],
  ['afegirtext',['AfegirText',['../class_biblio.html#aa4cbcfd32a3a2c4555c36cc465a9908c',1,'Biblio']]],
  ['aut_5fprocedent',['aut_procedent',['../class_cita.html#ac87eca62484c835f77988ce4276a5b55',1,'Cita']]],
  ['autor',['autor',['../class_biblio.html#a13ba429d214a2d4b840e20d49ec6c896',1,'Biblio']]]
];
