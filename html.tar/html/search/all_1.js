var searchData=
[
  ['biblio',['Biblio',['../class_biblio.html',1,'Biblio'],['../class_biblio.html#a8564ddeff41076001304d03ace300190',1,'Biblio::Biblio()']]],
  ['biblio_2ecc',['Biblio.cc',['../_biblio_8cc.html',1,'']]],
  ['biblio_2ehh',['Biblio.hh',['../_biblio_8hh.html',1,'']]],
  ['biblioteca',['Biblioteca',['../class_biblioteca.html',1,'']]]
];
