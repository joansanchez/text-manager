var searchData=
[
  ['elim_5fcit_5fset',['elim_cit_set',['../class_text.html#ab4b50eccf63d788aa10e3f14ae991dca',1,'Text']]],
  ['eliminarcita',['eliminarcita',['../class_biblio.html#a74f0c1875e00847f37f1988da82699bd',1,'Biblio']]],
  ['eliminartext',['EliminarText',['../class_biblio.html#ad3fd21f13f9164ddaba4009870b4fb02',1,'Biblio']]],
  ['expremin',['expremin',['../class_text.html#a446fdfbf5673d1a720514e4b723c8670',1,'Text']]],
  ['extra_5fexpre',['extra_expre',['../_text_8cc.html#ac2b262cca142c94c7c4b84ed61936bd4',1,'Text.cc']]]
];
