var searchData=
[
  ['frases',['frases',['../class_biblio.html#a6e901f7cbfdd5dd57f8baff7d16e514d',1,'Biblio::frases()'],['../class_text.html#ac1213313a2d7972b691bdec87395b41c',1,'Text::frases()']]],
  ['frasesexpresio',['frasesexpresio',['../class_biblio.html#ab350a61c300835e8a81dd4ce544d3125',1,'Biblio']]],
  ['frasesparaules',['frasesparaules',['../class_biblio.html#a9bfc7f88bddf98188eb07a48267e19ec',1,'Biblio::frasesparaules()'],['../class_text.html#a29f68a90075d7a9cbe7c5be6c89a8d6c',1,'Text::frasesparaules()']]]
];
