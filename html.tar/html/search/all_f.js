var searchData=
[
  ['valor_5fx',['valor_x',['../class_cita.html#a52e91ebf1dbd3d3a7d480337b75db2de',1,'Cita']]],
  ['valor_5fy',['valor_y',['../class_cita.html#a261908af4272a3ca2da58e019413ffe3',1,'Cita']]]
];
