var searchData=
[
  ['recursiva',['recursiva',['../class_text.html#a41f10550697cb67253a868a3a7bea95d',1,'Text']]],
  ['referencia',['referencia',['../class_cita.html#afcbd34adba6ea5d174ec67985be42f84',1,'Cita']]]
];
